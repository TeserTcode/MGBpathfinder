# MGBpathfinder
pathfinding and bruteforcing tool for miner gun biulder

features:
-basic pathfinding mode 1-(0-1-2-3-4-5)
-custom basic pathfinding 0
--to use a custom custom ship 
--in mgb open custom tile store 
--1  2  3
--4  5  6
--7  8  9
--10 11 12
-static bruteforce 4-1-(0-1-2-3-4-5)
-randomized optimum tile bruteforce 1-6
-randomized crazy tile bruteforce 1-7
-perfect tile bruteforce 1-8
-perfect wave tile bruteforce(not fully complete) 1-9
-configurable settings
--raytrace lenght
--telorance for shwoing the best
--extra quality for tile bruteforce
--number of empty tiles
--usable tiles in tile bruteforce
--retry for fail
--weights of tiles
--maximum iteration for pathfinding
